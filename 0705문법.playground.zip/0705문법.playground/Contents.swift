import UIKit

//1.변수상수타입 2.함수 3.조건문반복문
/*
변수나 상수 -이름을 정할때
 
 var userName:String = "jack"
 
 회원가입할때 비밀번호는 변경가능, 아이디는 변경 안함. - 변수 var 상수 let
 한가지 더 뭘 들어갈지도 알려줘야한다 - 그부분이 : 이다.
 
 데이터타입 ""있으면 문자.
 
 초기화 = 초기값
 
 var userName(선언) = "jack" (초기화)
 
 */

// < 1. 변수와 상수와 타입 >
// 1. 소개팅 앱 회원가입 - (모든데이터타입을 다 다룰수있기 때문)
// 기능 - 닉네임, 이메일, 성별, 평점, 나이
// 기획 -

var nickname = "고무고무"     // 특성 궁금할 때 = 애플 백과사전 => 커맨드 + 쉬프트 + 0
let email : String = "cshwan23@naver.com"
var gender : Bool = true // true : 남자, false : 여자 bool=참거짓
var rate : Double = 3.3 // Double = 소수점
var age : Int = 31

//화면 대용으로 출력 => print

print("안녕하세요 \(nickname)님 당신의 이메일은 \(email)이고 평점은 \(rate) 나이는 \(age)입니다.")


rate = 4.4

print("안녕하세요 \(nickname)님 당신의 이메일은 \(email)이고 평점은 \(rate) 나이는 \(age)입니다.")



//변수명을 출력하는 방법      \(변수명,상수명). 역슬래쉬+괄호

// 2. 영화 리포트 -총 감상한 영화 갯수 , 영화 러닝 타임 , 영화 평점, 좋아하는 장르

//var moviecount : Int  = 3
var moviecount : Int = Int.random(in: 1...1000) //...범위 연산자
var movierunningtime : Int = Int.random(in: 120...300000)
var moviescore : Double = Double.random(in: 1...5) //더블은 상세하게 길게 나옴. 소수점 너무 긴데 강제로 숫자로 보이게 하겠다. Int() 형변환
var moviegenre : String = "멜로"

print("지금까지 본 영화 \(moviecount)개, 총 러닝타임 \(movierunningtime), 평점 \(Int(moviescore)), 장르 \(moviegenre)")
